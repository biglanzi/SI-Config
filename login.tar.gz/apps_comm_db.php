<?php
require_once('macro.inc.php');
require_once('db_utils.php');



class CAppsCommDB{
	public $db_operator;
	public $fields;
	public $err;
	
	public $db_name;
	public $tab_name;
	
	public $affectedRowCount;
	
	public function __construct($db=APPS_DB, $tab=APPS_TAB)
	{
		$this->db_operator = new db_operator(USER_DB_LINK, USER_DB_USER, USER_DB_PASS);
		if($this->db_operator->connect() !== 0){
			$this->err = sprintf("connect db error: %s", $this->db_operator->get_error_info());
			$this->db_operator = false;
		}
		else{
			$this->db_operator->update("set names utf8");
		}
		$this->fields = false;
		$this->db_name = $db;
		$this->tab_name = $tab;
	}
	
	public function Fields()
	{
		if($this->fields === false){
			$field_list = new record_list();
			$statment = sprintf("desc %s.%s", $this->db_name, $this->tab_name);
			$ret = $this->db_operator->get_record_list($statment, $field_list, PDO::FETCH_ASSOC);
			if ($ret != 0){
				$this->err = sprintf("get record list error: %s", $this->db_operator->get_error_info());
				return false;
			}
			
			$this->fields = array();
			foreach($field_list->record_list as $field){
				$this->fields[$field['Field']] = $field;
			}
		}
		
		return $this->fields;
	}
	
	public function ConcateCondition($conds)
	{
		$query = '';
		
		$fcnt = 0;
		foreach($conds as $cond){
			foreach($cond as $fname => $v){
					if($fcnt == 0)
						$query .= ' where ';
					else
						$query .= ' and ';
					if(is_array($v)){
							$query .= '`'.$fname.'`'.$v[0].$v[1];
					}
					else{
							$query .= '`'.$fname.'`='.$v;
					}
					
					$fcnt++;
			}
		}
		
		return $query;
	}
	
	public function ConcateBindCondition($conds, &$cond_bind)
	{
		$query = '';
		
		$fcnt = 0;
		foreach($conds as $cond){
			foreach($cond as $fname => $v){
					if($fcnt == 0)
						$query .= ' where ';
					else
						$query .= ' and ';
					$bname = ':'.$fcnt.$fname;
					if(is_array($v)){
						$query .= '`'.$fname.'`'.$v[0].$bname;
						if(is_int($v[1]))
							$btype = PDO::PARAM_INT;
						else
							$btype = PDO::PARAM_STR;
						$cond_bind[] = array($bname, $v[1], $btype);
					}
					else{
						$query .= '`'.$fname.'`='.$bname;
						if(is_int($v))
							$btype = PDO::PARAM_INT;
						else
							$btype = PDO::PARAM_STR;
						$cond_bind[] = array($bname, $v, $btype);
					}
					
					$fcnt++;
			}
		}
		
		return $query;
	}
	
	public function Get($conds, $order='')
	{
		$this->db_operator->update("set names utf8");
		
		$fields = $this->Fields();
		if($fields === false){
			return false;	
		}
		
		$record_list = new record_list();
		$query = sprintf("select * from %s.%s ", $this->db_name, $this->tab_name);
		$query .= $this->ConcateCondition($conds);
		
		if(strlen($order) > 0){
			$query .= " ".$order;
		}
		
		
		$ret = $this->db_operator->get_record_list($query, $record_list, PDO::FETCH_ASSOC);
		if ($ret != 0) {
			$this->err = sprintf("get record list error: %s", $this->db_operator->get_error_info());
			return false;
		}
		if(is_null($record_list->record_list)){
			return array();
		}
		
		foreach($fields as $field){
			// ignore bigint here, because PHP do not support bigint in 32-bit platform
			if(strncasecmp($field["Type"],"int",3)==0 || strncasecmp($field["Type"],"tinyint",7)==0 || strncasecmp($field["Type"],"smallint",8)==0 || strncasecmp($field["Type"],"mediumint",9)==0){
				for($i=0; $i < count($record_list->record_list); $i++){
					if(isset($record_list->record_list[$i][$field["Field"]]))
						$record_list->record_list[$i][$field["Field"]] = intval($record_list->record_list[$i][$field["Field"]]);
				}
			}
		}
		
		return $record_list->record_list;
	}
	
	// unlike other methods, string value don't include with ""
	public function SafeGet($conds, $order='', $select_fields=array())
	{
		$this->db_operator->update("set names utf8");
		
		$fields = $this->Fields();
		if($fields === false){
			return false;	
		}
		
		if(count($select_fields) == 0)
			$query = sprintf("select * from `%s`.`%s` ", $this->db_name, $this->tab_name);
		else{
			$fstr = '';
			for($i=0; $i < count($select_fields); $i++){
				if($i > 0)
					$fstr .= ',';
				$fstr .= '`'.$select_fields[$i].'`';
			}
			$query = sprintf("select %s from `%s`.`%s` ", $this->db_name, $this->tab_name, $fstr);
		}
		$cond_bind = array();
		$query .= $this->ConcateBindCondition($conds, $cond_bind);
		
		if(strlen($order) > 0){
			$query .= " ".$order;
		}
		
		// bind
		$row = array();
		$ret = $this->db_operator->prepare($query, $stmt);
		if($ret != 0){
			$this->err = sprintf("db prepare error: %s", $this->db_operator->get_error_info());
			return false;
		}
		try{
			foreach($cond_bind as $idx => $row){
				$stmt->bindParam($row[0], $cond_bind[$idx][1], $row[2]);
			}
		}
		catch (PDOException $e){
		   $this->err = sprintf("PDO bindParam error [%s]", $e->getMessage());
		   return false;
		}
		
		try{
			$stmt->execute();
		}
		catch (PDOException $e){
			$this->err = sprintf("PDO execute error[%s]", $e->getMessage());
			return false;
		}
		
		$stmt->setFetchMode(PDO::FETCH_ASSOC);
		
		$record_list = $stmt->fetchAll();
		
		foreach($fields as $field){
			// ignore bigint here, because PHP do not support bigint in 32-bit platform
			if(strncasecmp($field["Type"],"int",3)==0 || strncasecmp($field["Type"],"tinyint",7)==0 || strncasecmp($field["Type"],"smallint",8)==0 || strncasecmp($field["Type"],"mediumint",9)==0){
				for($i=0; $i < count($record_list); $i++){
					if(isset($record_lis[$i][$field["Field"]]))
						$record_list[$i][$field["Field"]] = intval($record_list[$i][$field["Field"]]);
				}
			}
		}
		
		return $record_list;
	}
	
	private function IsInt($fname)
	{
		if(isset($this->fields[$fname])){
			$type = $this->fields[$fname]["Type"];
			if(strncasecmp($field["Type"],"int",3)==0 || strncasecmp($field["Type"],"bigint",6)==0 || strncasecmp($field["Type"],"tinyint",7)==0 || strncasecmp($field["Type"],"smallint",8)==0 || strncasecmp($field["Type"],"mediumint",9)==0)
				return(1);
		}
		
		return(0);
	}
	
	public function Update($update, $cond_fields=array("id" => 1))
	{
		if(count($update) == 0)
			return true;
		
		$fields = $this->Fields();
		if($fields === false)
			return false;
			
		// sql
		$up_fields = array();
		
		//ȡ����һ��Ԫ��,�ж��ĸ��ֶ�Ҫ����,����update field
		foreach($update[0] as $fname => $fv){
			if(isset($fields[$fname]) && !isset($cond_fields[$fname])){
				$up_fields[$fname] = 1;
			}
		}
		if(count($up_fields) < 1){
			$this->err = 'missing update fields';
			return false;
		}
		
		$fcnt = 0;
		$query = 'update '.$this->db_name.'.'.$this->tab_name.' set '; 
		foreach($up_fields as $fname => $v){
			if(!isset($fields[$fname]))
				continue;
			
			if($fcnt > 0)
					$query .= ',';
			
				$query .= '`'.$fname.'`=:'.$fname;
			$fcnt++;
		}
		$fcnt = 0;
		foreach($cond_fields as $fname => $v){
			if(!isset($fields[$fname]))
				continue;
			
				if($fcnt == 0)
					$query .= ' where ';
				else
					$query .= ' and ';
				
				$query .= '`'.$fname.'`=:'.$fname;
				
				$fcnt++;
		}
		
		// bind
		$row = array();
		$ret = $this->db_operator->prepare($query, $stmt);
		if($ret != 0){
			$this->err = sprintf("db prepare error: %s", $this->db_operator->get_error_info());
			return false;
		}
		try{
			foreach($up_fields as $fname => $v){
				if(!isset($fields[$fname]))
					continue;
					
				if($this->IsInt($fname))
					$stmt->bindParam(':'.$fname, $row[$fname], PDO::PARAM_INT);
				else
					$stmt->bindParam(':'.$fname, $row[$fname], PDO::PARAM_STR);
			}
			foreach($cond_fields as $fname => $v){
				if(!isset($fields[$fname]))
					continue;
					
				if($this->IsInt($fname))
					$stmt->bindParam(':'.$fname, $row[$fname], PDO::PARAM_INT);
				else
					$stmt->bindParam(':'.$fname, $row[$fname], PDO::PARAM_STR);
			}
		}
		catch (PDOException $e){
		   $this->err = sprintf("PDO bindParam error [%s]", $e->getMessage());
		   return false;
		}
		
		foreach($update as $up){
			foreach($up_fields as $fname => $v)
				$row[$fname] = $up[$fname];
			foreach($cond_fields as $fname => $v)
				$row[$fname] = $up[$fname];
		
			try{
					$stmt->execute();
		  }
		  catch (PDOException $e){
					$this->err = sprintf("PDO execute error[%s]", $e->getMessage());
					return false;
		  }
		  
		  $this->affectedRowCount = $stmt->rowCount();
		}
		
		return true;
	}
	
	
	public function Insert($app, $ignore=false)
	{
		if(count($app) == 0)
			return true;
		
		$fields = $this->Fields();
		if($fields === false)
			return false;
			
		$fcnt = 0;
		$query = sprintf('insert %s into '.$this->db_name.'.'.$this->tab_name.' set ', $ignore ? "ignore":""); 
		foreach($app as $fname => $v){
			if(!isset($fields[$fname]))
				continue;
				
			if($fcnt > 0)
					$query .= ',';
			
				$query .= '`'.$fname.'`=:'.$fname;
			$fcnt++;
		}
		
		// bind
		$row = array();
		$ret = $this->db_operator->prepare($query, $stmt);
		if($ret != 0){
			$this->err = sprintf("db prepare error: %s", $this->db_operator->get_error_info());
			return false;
		}
		try{
			foreach($app as $fname => $v){
				if(!isset($fields[$fname]))
					continue;
			
				if($this->IsInt($fname))
					$stmt->bindParam(':'.$fname, $app[$fname], PDO::PARAM_INT);
				else
					$stmt->bindParam(':'.$fname, $app[$fname], PDO::PARAM_STR);
			}
		}
		catch (PDOException $e){
		   $this->err = sprintf("PDO bindParam error [%s]", $e->getMessage());
		   return false;
		}
		
		try{
			$stmt->execute();
		}
		catch (PDOException $e){
			$this->err = sprintf("PDO execute error[%s]", $e->getMessage());
			return false;
		}
		
		$id = $this->db_operator->get_Last_InsertID(); 
		$this->affectedRowCount = $stmt->rowCount();
		
		return $id;
	}
	
	public function Replace($app)
	{
		if(count($app) == 0)
			return true;
		
		$fields = $this->Fields();
		if($fields === false)
			return false;
			
		$fcnt = 0;
		$query = 'replace into '.$this->db_name.'.'.$this->tab_name.' set '; 
		foreach($app as $fname => $v){
			if(!isset($fields[$fname]))
				continue;
			
			if($fcnt > 0)
					$query .= ',';
			
				$query .= '`'.$fname.'`=:'.$fname;
			$fcnt++;
		}
		
		// bind
		$row = array();
		$ret = $this->db_operator->prepare($query, $stmt);
		if($ret != 0){
			$this->err = sprintf("db prepare error: %s", $this->db_operator->get_error_info());
			return false;
		}
		try{
			foreach($app as $fname => $v){
				if(!isset($fields[$fname]))
					continue;
					
				if($this->IsInt($fname))
					$stmt->bindParam(':'.$fname, $app[$fname], PDO::PARAM_INT);
				else
					$stmt->bindParam(':'.$fname, $app[$fname], PDO::PARAM_STR);
			}
		}
		catch (PDOException $e){
		   $this->err = sprintf("PDO bindParam error [%s]", $e->getMessage());
		   return false;
		}
		
		try{
			$stmt->execute();
		}
		catch (PDOException $e){
			$this->err = sprintf("PDO execute error[%s]", $e->getMessage());
			return false;
		}
		
		$id = $this->db_operator->get_Last_InsertID(); 
		$this->affectedRowCount = $stmt->rowCount();
		
		return $id;
	}
	
	// ���ɶ���sql��һ���������϶�����������
	public function SQLGet($query)
	{
		$this->db_operator->update("set names utf8");
		
		$ret = $this->db_operator->get_record_list($query, $record_list, PDO::FETCH_ASSOC);
		if ($ret != 0) {
			$this->err = sprintf("get record list error: %s", $this->db_operator->get_error_info());
			return false;
		}
		if(is_null($record_list->record_list)){
			return array();
		}
		
		return $record_list->record_list;
	}
}

?>
