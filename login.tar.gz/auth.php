<?php

function auth()
{
	
	$servername 	= "localhost";
	$username 		= "root";
	$password 		= "";
	$dbname			= "icp";
	$tabname		= "Login";
	
	$usr 		= $_POST['account'];
	$passwd 	= $_POST['passwd'];
	
	$con =mysql_connect($servername, $username, $password,$dbname);
	mysql_select_db($tabname, $con);
	$mdv = md5($usr.$passwd."p");
	$sql ="SELECT * FROM $tabname WHERE mixvalue='$mdv'";
	$result = $mysql_query($sql,$con);

	
	// if($result->num_rows >０)
	// {
		// require_once('filter.php');
	// }
	// else
	// {
		// echo '<script>javaScript:window.location.href=\'index.html\';</script>';
	// }
}
auth();
?>