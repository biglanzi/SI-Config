<?php 
define("APPS_DB", "icp");
define("APPS_TAB", "Log");
define("APPS_INFO_TAB", "t_ios_app_info");
define("APPS_KEYWORD_TAB", "t_keyword");
define("APPS_APP_KEYWORD_TAB", "t_app_keyword");
define("APPS_BIG_APP_TAB", "t_big_apps");

define("USER_DB", "icp");
define("USER_DB_LINK", "mysql:host=localhost;db=" . SYS_DB);
define("USER_DB_USER", "root");
define("USER_DB_PASS", "");

define("APPS_LOG_PATH", '/data/log/apps');

// ������
define("RTN_SUCCESS", 0);
define("ERR_NOT_LOGIN", 1001);
define("ERR_INVALID_SESSION", 1002);
define("ERR_LOGIN_EXPIRED", 1003);
define("ERR_NO_SUCH_USER", 1004);
define("ERR_PASS_ERR", 1005);
define("ERR_USER_STATUS", 1006);
define("ERR_USER_NO_GROUP", 1007);
define("ERR_USER_NO_SUCH_GROUP", 1008);
define("ERR_USER_NO_PRIV", 1009);

define("ERR_DB_EXCEPTION", 2001);
define("ERR_DB_QUERY", 2002);
define("ERR_UPD_CURR_GID_FAILED", 2010);
define("ERR_MENU_NOT_EXIST", 2011);

define("ERR_INVALID_INPUT", 3001);

?>
