<?php
session_start();
require_once('navigation.php');

function query_log(){
	if(isset($_SESSION['userName'])){
		
		$servername 	= "localhost";
		$username 		= "root";
		$password 		= "";
		$dbname			= "icp";

		$stTm			=  $_POST['startTime'];
		$endTm			=  $_POST['endTime'];
		$name			=  $_POST['usrname'];
		$ip				=  $_POST['ip'];
		$action			=  $_POST['action'];
		
		$con =new mysqli($servername, $username, $password,$dbname);

		echo "<br><br><br>";
		echo '<div style="text-align:center"><h3>日志查询:</h3>'.'<br>';
		echo '
		<form action = "test.php" method="post">
			开始时间
			<input type="date" name= "startTime">
			结束时间
			<input type="date" name= "endTime">
			用户名
			<input type="input" name= "usrname">
			
			IP
			<input type="input" name= "ip">
			操作
			<input type="input" name= "action">
			<input type="submit">
		</form></div>
		';
		$sql = "SELECT * FROM Log WHERE 1=1";
		if($name != null)			
			$sql = $sql." AND roleName='$name'";
		if($ip != null)
			$sql = $sql." AND ip='$ip'";
		if($action != null)
			$sql = $sql." AND action='$action'";

		$result = $con->query($sql);
		if($result->num_rows > 0)
		{
			echo '<div style="margin:0 auto;"><table class="tbl_1" align="center">
			<thead>
			  <tr>
				<th>时间</th>
				<th>IP</th>
				<th>用户</th>
				<th>操作</th>
			  </tr></thead>';

			//show info
			while($row = $result->fetch_assoc())
			{
					
				if(((strncmp($row['time'],$stTm,10)>=0) && (strncmp($row['time'],$endTm,10)<=0))
					||(($stTm == null)&&(strncmp($row['time'],$endTm,10)<=0))
					||(($endTm == null)&&(strncmp($row['time'],$stTm,10)>=0))
					||(($stTm == null)&&($endTm == null)))
				{
					echo "
					<tr>
						<td>".$row['time']."</td>
						<td>".$row['ip']."</td>
						<td>".$row['roleName']."</td>
						<td>".$row['action']."</td>
					</tr>
					";
					
				}
				
			}
			echo '</table>';
			echo '</div>';
		}
		else
		{
			echo "0 个结果";
		}
	}
	else
	{
		$url = 'index.php';
		echo "<script>"; 
		echo "location.href='$url'"; 
		echo "</script>"; 
	}
}
query_log();
exit();

?>
