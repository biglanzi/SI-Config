<?php
//this php file implements add keyword filter interface
session_start();
require_once('navigation.php');

function filter()
{
	if(isset($_SESSION['userName']))
	{		
		$servername 	= "localhost";
		$username 		= "root";
		$password 		= "";
		$dbname			= "icp";
		
		$con =new mysqli($servername, $username, $password,$dbname);

		echo "<br><br><br>";
		echo '<div style="text-align:center">';
		echo "在下面的输入框中输入你要过滤的关键词："."<br><br>";
		echo
		'
		<form action="insert_keyword.php" method="post">
			<input name ="keyword"  type="text"></input>
			<input class="btn" id ="link" name="submit" type = "submit"></input>
		</form>
		';

		$sql = "SELECT * FROM ky_filter";
		$result = $con->query($sql);
		if($result->num_rows > 0)
		{
			$cnt = 0;
			//show info
			echo '<div style="margin:0 auto;"><table align="center" class="tbl_1">
				<thead>
				<tr>
					<th>编号</th>
					<th>内容</th>
				 </tr>
				 </thead>
			  ';
			while($row = $result->fetch_assoc())
			{
				$cnt = $cnt + 1;
				echo "
				<tr>
					<td>$cnt</td>
					<td>$row[keyword]</td>
				</tr>
				";
				//echo "$cnt "."&nbsp".$row["keyword"]."<br>";
			}
			
		}
		else
		{
			echo "0 个结果";
			
		}
		
		echo '</div>';
		echo '<script></script>';

		$con->close();
	}
	else
	{
		$url = 'index.php';
		echo "<script>"; 
		echo "location.href='$url'"; 
		echo "</script>"; 
	}
}
filter();
?>
