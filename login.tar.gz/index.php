<?php
session_start();

if(!isset($_SESSION['userName']))
{
	if(($_POST['account'] != null)&&($_POST['passwd']) != null)
	{
		
		$servername 	= "localhost";
		$username 		= "root";
		$password 		= "";
		$dbname			= "icp";

		$tabname		= "Login";
		$tabLog			= "Log";
		$ip				= getenv("REMOTE_ADDR");
		$userClass		= Array("开发人员1","系统管理员","运营人员","系统维护");
		$actClass		= Array("修复更新","日志查询","报表更新","系统维护");	
		
		$usr 			= $_POST['account'];
		$passwd 		= $_POST['passwd'];
		
		$con			=new mysqli($servername, $username, $password,$dbname);
		$mdv			= md5($usr.$passwd."p");
		$sql			="SELECT * FROM $tabname WHERE mixvalue='$mdv'";
		$result			= $con->query($sql);
		if($result->num_rows >０)
		{
			//插入新的登录日志
			$row	= $result->fetch_assoc();
			$usrcls = $userClass[$row['userclass']];
			$actcls = $actClass[$row['userclass']];

			$sql	= "INSERT INTO $tabLog (roleName,ip,action) VALUES ('$usrcls','$ip','$actcls')";
			$con->query($sql);
						
			$_SESSION['userName']	= $usr;
			$_SESSION['password']	= $passwd;
			header('Location: filter.php');
		}
		$con->close();
	}
}
else
{
	header('Location: filter.php');
}
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/login.css"/>
<title> 后台审核</title>
<script type="text/javascript" src="script/jquery.min.js"></script>
<style type="text/css">

</style>
</head>
<body>
<div class="main">
	<div class="content">
		<div class="title hide"></div>
		<form name="login" action="index.php" method="post">
			<fieldset>
				<div class="input">
					<input class="input_all name" name="account" id="name" placeholder="账号" type="text" onFocus="this.className='input_all name_now';" onBlur="this.className='input_all name'" maxLength="24" />
				</div>
				<div class="input">
					<input class="input_all password" name="passwd" id="password" type="password" placeholder="密码" onFocus="this.className='input_all password_now';" onBlur="this.className='input_all password'" maxLength="24" />
				</div>
				<div class="enter">
					<input class="button hide" name="submit" type="submit" value="" />
				</div>
				<img alt="" src="" onclick="">
			</fieldset>
		</form>
	</div>
</div>
<script type="text/javascript" src="script/placeholder.js"></script>

</body>
</html>
