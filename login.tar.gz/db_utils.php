<?php

// DB相关的公共操作集合
///////////////////////////////////////////////////////////////////////////////////////////////////
// 结果集保存类
// 记录总条数和结果数据
class record_list
{
	var $total_count;
	var $record_list;
	var $record_value; //为显示市场活动问题值加上此字段
	
	function record_list()
	{
		$this->total_count = 0;
	}
	
}

// 结果集保存类
// 记录总条数，当前页，页码信息，以及当前页结果集信息
class record_list_page
{
	var $total_count; // 总条数
	var $display_page; // 需要显示的页数
	var $curr_page; // 当前页码
	var $page_size; // 每页记录数量
	var $page_list; // 生成的页码数组
	var $curr_page_size; // 当前页的结果数量
	var $record_list; // 结果集
	
	// 设置页码信息
	function set_page_info($curr_page, $page_size, $display_page)
	{
		$this->curr_page    = $curr_page;
		$this->page_size    = $page_size;
		$this->display_page = $display_page;
	}
	
	// 计算页码，生成一个页码数组
	function count_page_list()
	{
		// 每页数量错误，直接返回
		if ($this->page_size == 0) {
			return;
		}
		
		$start_page = 0;
		$end_page   = 0;
		$total_page = (int) ($this->total_count / $this->page_size);
		$half_page  = (int) ($this->display_page / 2);
		
		if (($this->total_count % $this->page_size) > 0)
			$total_page++;
		
		// 总页数少于需要显示的页数，直接从1开始显示页码
		if ($total_page <= $this->display_page) {
			$start_page = 1;
			$end_page   = $total_page;
		}
		// 根据边界条件进行判断和移位
		else {
			$start_page = $this->curr_page - $half_page;
			$end_page   = $this->curr_page + $half_page;
			
			if ($start_page <= 0) {
				$start_page = 1;
				$end_page   = $this->display_page;
			} else if ($end_page > $total_page) {
				$end_page   = $total_page;
				$start_page = $total_page - $this->display_page + 1;
			}
		}
		
		// 根据开始和结束页码生成一个页码数组
		for ($i = $start_page; $i <= $end_page; $i++) {
			$this->page_list[] = $i;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////

// DB操作类
// 使用PDO进行DB相关操作，并支持多次操作
// 内部会控制是否连接的状态
class db_operator
{
	var $dbh;
	var $error;
	var $link_str;
	var $user;
	var $pass;
	var $linked;
	
	// 设置相关链接参数
	function db_operator($link, $user, $pass)
	{
		$this->link_str = $link;
		$this->user     = $user;
		$this->pass     = $pass;
		$this->linked   = 0;
	}
	
	function get_error_info()
	{
		return $this->error;
	}
	
	// 建立数据库连接
	function connect()
	{
		// 判断是否已经连接，如果是则直接返回，如果没有则进行连接
		if ($this->linked == 1) {
			return 0;
		}
		try {
			$this->dbh = new PDO($this->link_str, $this->user, $this->pass);
			// 设置PDO操作错误时抛出异常
			$this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->dbh->exec("set names utf8");
		}
		catch (PDOException $e) {
			$this->error = sprintf("DBConnect failed: %s", $e->getMessage());
			return ERR_DB_EXCEPTION;
		}
		$this->linked = 1;
		return 0;
	}
	
	// 查询结果集（查询全部结果，因此不需要计算总条数）
	function get_record_list($sql_string, &$record_list, $fetch_mode = PDO::FETCH_BOTH)
	{
		// 链接数据库
		$ret = $this->connect();
		if ($ret != 0) {
			return $ret;
		}
		
		// 查询
		$record_list = new stdClass();
		$record_list->total_count = 0;
		try {
			$res = $this->dbh->query($sql_string);
			$res->setFetchMode($fetch_mode);
			foreach ($res as $row) {
				$record_list->record_list[] = $row;
				$record_list->total_count++;
			}
		}
		catch (PDOException $e) {
			$this->error = sprintf("DBQuery failed: %s", $e->getMessage());
			return ERR_DB_QUERY;
		}
		return 0;
	}
	
	function get_Last_InsertID()
	{
		$id = $this->dbh->lastInsertId();
		return $id;
	}
	
	// 查询结果集（查询部分结果，步骤为计算总条数，然后计算当前页的数据）
	// NOTICE：在result_sql里面会自动加上limit 100,200之类的信息，外面不需要传入
	function get_record_list_page($count_sql, $result_sql, $curr_page, $page_size, $display_page, &$record_list_page)
	{
		// 判断参数
		if ($curr_page < 1 || $page_size < 1 || $display_page < 1) {
			$this->error = sprintf("参数错误！");
			return ERR_INV_INPUT;
		}
		
		// 链接数据库
		$ret = $this->connect();
		if ($ret != 0) {
			return $ret;
		}
		
		$record_list_page->set_page_info($curr_page, $page_size, $display_size);
		$cur_sql = "";
		try {
			// 查询总条数，如果是0也是成功，返回
			$cur_sql = $count_sql;
			foreach ($this->dbh->query($count_sql) as $row) {
				$record_list_page->total_count = (int) $row['count(*)'];
			}
			if ($record_list_page->total_count == 0) {
				return 0;
			}
			
			// 查询结果集
			$sql_string                       = sprintf("%s limit %d, %d", $result_sql, ($curr_page - 1) * $page_size, $page_size);
			$record_list_page->curr_page_size = 0;
			$cur_sql                          = $sql_string;
			foreach ($this->dbh->query($sql_string) as $row) {
				$record_list_page->record_list[] = $row;
				$record_list_page->curr_page_size++;
			}
			// 计算页码
			$record_list_page->count_page_list();
		}
		catch (PDOException $e) {
			$this->error = sprintf("DBQuery[%s] failed: %s", $cur_sql, $e->getMessage());
			return ERR_DB_QUERY;
		}
		return 0;
	}
	
	// 插入和更新操作函数
	function update($sql_string)
	{
		// 链接数据库
		$ret = $this->connect();
		if ($ret != 0) {
			return $ret;
		}
		
		try {
			// 注意这里返回的是更新的条数，从>=0都是正常的，错误通过exception返回了
			$result = $this->dbh->exec($sql_string);
		}
		catch (PDOException $e) {
			$this->error = sprintf("DBExec failed: %s", $e->getMessage());
			return ERR_DB_QUERY;
		}
		return 0;
	}
	
	function prepare($sql_string, &$stmt)
	{
		// 链接数据库
		$ret = $this->connect();
		if ($ret != 0) {
			return $ret;
		}
		
		try {
			$stmt = $this->dbh->prepare($sql_string);
		}
		catch (PDOException $e) {
			$this->error = sprintf("DBPrepare failed: %s", $e->getMessage());
			return ERR_DB_QUERY;
		}
		return 0;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////



?>