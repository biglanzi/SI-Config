<?php
function insert_key(){
	
	$servername 	= "localhost";
	$username 		= "root";
	$password 		= "";
	$dbname			= "icp";

	$kyword = $_POST['keyword'];
	$con =new mysqli($servername, $username, $password,$dbname);
	$sql = "INSERT INTO ky_filter (keyword) VALUES ('$kyword')";
	
	if($kyword != null && $kyword !="")
		$con->query($sql);
	$con->close();

	require('filter.php');
}
insert_key();

?>
