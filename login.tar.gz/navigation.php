<?php
//common header part
echo '
	<head>
	<meta charset="utf-8"{>
		<style type="text/css">
			.sbmt:hover{font-size:18px}
		</style>
		<link rel="stylesheet" type="text/css" href="css/tbl.css"/>
	</head>
	<div  style = "margin-top:50px;text-align:center">
		<div style="width:30%;padding:0;margin:10px;float:left;">
		<form  action="filter.php" method="post">
			<input class="btn" type="submit" name="filter" value="关键词过滤" id="Button1" class="join-btn">
		</form>
		</div>     
		
		<div style="width:30%;padding:0;margin:10px;float:left;">
			<form  action="query_log.php" method="post">
			<input class="btn" type="submit" name="queryLog" value="日志查询" id="Button2" class="join-btn">
			</form>
		</div>
		
		<div style="width:30%;padding:0;margin:10px;float:left;">
			<form action="login_out.php" method="post">
			<input class="btn" type="submit" name="loginout" value="退出登录" id="Button3"  >
			</form>
		</div>
	</div>
';
?>
